//=============================================================================
// Plugin for RPG Maker MZ
// ProcessAllSameTileID.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc By set a switch, erase/rebuild all tiles whose id is the same.
 * @author Sasuke KANNAZUKI
 *
 * @help This plugin does not provide plugin commands.
 * This plugin runs under RPG Maker MZ.
 *
 * This plugin enables to delete/resume all tiles of specified id in the map,
 * whose handler is a specified switch.
 *
 * It means a switch id interlocks to a tile of specified id.
 * You can at most 20 interlock switches and specified tile in one map.
 *
 * [Summary]
 * To set the pairs of switch ID and tile ID, you need to make dummy event.
 * For each page, set switch 1 as switch id, and set image to specify tile.
 * Note that image must be tile, otherwise the setting of the page is ignored.
 * 
 * Describe the event's note <SwitchToTileId> , and the event become dummy
 * event to set this plugin's settings.
 *
 * I recommend you to such dummy event is prefer to be invisible.
 * To realize dummy event invisible...
 * - put the event at in the wall.
 * - Set the last page(= largest page number) no image and no conditions.
 *
 * Interlocked tiles vanishes when specified switch become ON,
 * and appears again when the switch become OFF.
 * (Needless to say, switch's default value is OFF.)
 *
 * Note that those settings are valid only in the map.
 * If you need to set plural maps, you must put the dummy event for each map.
 *
 * [Example Usage]
 * Make the puzzle gimic in the dungeon.
 * Player must toggle several switches to reach destination.
 *
 * And I know we can make such gimic without using plugin instead events,
 * I believe using this plugin is much easier and remove burden of
 * making quite a few events and the risk to implement bugs.
 *
 * [License]
 * this plugin is released under MIT license.
 * http://opensource.org/licenses/mit-license.php
 */

/*:ja
 * @target MZ
 * @plugindesc スイッチのON/OFFでマップ上の特定のタイルID全てを消去/復元します。
 * @author 神無月サスケ
 *
 * @help このプラグインにプラグインコマンドはありません。
 * このプラグインは、RPGツクールMZに対応しています。
 *
 * このプラグインは、特定のスイッチを押すと、特定のIDのタイルをすべて
 * 一括で消去したり、復活させたりすることができます。
 * 
 * すなわち、スイッチIDにタイルIDの紐づけを行っているのですが、
 * １マップに複数の紐づけを行うことが可能です。（現在は最大20個まで）
 *
 * ■概要
 * スイッチIDとタイルIDの紐づけは、設定専用のダミーのイベントを作成し行います。
 * 設定を行うイベントのメモ欄に <SwitchToTileId> と書いてください。
 * 各ページごとに、画像に設定したいタイル（キャラクターは不可）を、
 * 1番目のスイッチに、そのタイルに紐づけするスイッチを指定してください。
 * それ以外の設定は無視されます。
 *
 * 上記のようなダミーイベントは、一番後ろのページに何の条件もない画像のない
 * ページを設けるといいでしょう。そして壁の中など進入不可能な場所に置きます。
 *
 * 該当するスイッチがOFFの時が通常で、ONにすると、紐づけられたタイルが
 * 一斉に消えます。もう一度OFFにすると復活します。
 *
 * スイッチとタイルIDの紐づけは、その設定を行ったマップ内でのみ有効で、
 * 複数のマップに適用したい場合、それぞれのマップに上記のダミーイベントを
 * 設置する必要があります。
 *
 * ■使用例
 * 迷路的なパズルが作成できます。ブロックなどとスイッチを紐づけ、
 * スイッチを押すとブロックが一斉に消える……といった演出が可能です。
 *
 * なお、このプラグインで可能なことは、イベントでも作成できますが、
 * 設定の手間などを考慮すると、このプラグインの方がよいと思われます。
 *
 * ■ライセンス表記
 * このプラグインは MIT ライセンスで配布されます。
 * ご自由にお使いください。
 * http://opensource.org/licenses/mit-license.php
 */

(() => {
  const pluginName = 'ProcessAllSameTileID';

  //
  // set various temporal data to $gameTemp
  //
  const _Game_Temp_initialize = Game_Temp.prototype.initialize;
  Game_Temp.prototype.initialize = function() {
    _Game_Temp_initialize.call(this);
    this.resetTileHash();
  };

  Game_Temp.prototype.resetTileHash = function () {
    this._mapIdForTileSet = null;
    this._hasTileSetEvent = null;
    this.tileIdOfSwitchId = null; // {switch Id => tile Id}
    this.valueOfSwitchId = null;  // {switch Id => true/false}
    this.indicesOfTileId = null;  // {tile Id => array of data index}
  };

  Game_Temp.prototype.initTileHash = function () {
    this.tileIdOfSwitchId = {};
    this.valueOfSwitchId = {};
    this.indicesOfTileId = {};
  };

  //
  // check if the map has the setting event
  //
  const isSettingEvent = event => !!event.meta.SwitchToTileId;

  const doesTheMapHaveSettingEvent = () => {
    return $dataMap.events.filter(e => !!e).some(e => isSettingEvent(e));
  };

  const hasSettingEvent = () => {
    if ($gameTemp._hasTileSetEvent == null ||
      $gameMap.mapId() !== $gameTemp._mapIdForTileSet) {
      $gameTemp._mapIdForTileSet = $gameMap.mapId();
      $gameTemp._hasTileSetEvent = doesTheMapHaveSettingEvent();
    }
    return $gameTemp._hasTileSetEvent;
  };

  const settingEventId = () => {
    const event = $dataMap.events.filter(e => !!e).find(e => isSettingEvent(e));    return event ? event.id : 0;
  };

  //
  // analyze setting event and set hash, variables and so on.
  //
  const _Game_Map_setupEvents = Game_Map.prototype.setupEvents;
  Game_Map.prototype.setupEvents = function() {
    _Game_Map_setupEvents.call(this);
    this._processSettingEvent();
  };

  Game_Map.prototype._processSettingEvent = function () {
    if (!hasSettingEvent() || !settingEventId()) {
      return;
    }
    const eventId = settingEventId();
    for (const page of $dataMap.events[eventId].pages) {
      const switchId = page.conditions.switch1Id;
      const tileId = page.image.tileId;
      if (!switchId || !tileId) {
        continue;
      }
      if ($gameTemp.tileIdOfSwitchId == null) {
        $gameTemp.initTileHash();
      }
      $gameTemp.tileIdOfSwitchId[switchId] = tileId;
      $gameTemp.valueOfSwitchId[switchId] = false;
      if (!$gameTemp.indicesOfTileId[tileId]) {
        $gameTemp.indicesOfTileId[tileId] = indicesOfTileIdIs(tileId);
      }
    }
  };

  const indicesOfTileIdIs = tile_id => {
    if (!tile_id || !$dataMap.data) {
      return [];
    }
    const map = $dataMap;
    const data = map.data;
    let indices = [];
    for (let i = 0; i < map.width * map.height * 4; i++) {
      if (data[i] && data[i] == tile_id) {
        indices.push(i);
      }
    }
    return indices;
  };

  //
  // observe several switches' change
  //
  const _Game_Map_update = Game_Map.prototype.update;
  Game_Map.prototype.update = function(sceneActive) {
    _Game_Map_update.call(this, sceneActive);
    observeSwitchChange();
  };

  const observeSwitchChange = () => {
    if ($gameTemp.valueOfSwitchId) {
      const switchHash = $gameTemp.valueOfSwitchId;
      for (const switchId in switchHash) {
        const value1 = !!switchHash[+switchId];
        const value2 = $gameSwitches.value(+switchId);
        if (value1 !== value2) {
          switchHash[+switchId] = value2;
          modifyMapTile(+switchId);
        }
      }
    }
  };

  //
  // execute map tile modification
  //
  const modifyMapTile = switchId => {
    if (!$gameTemp.tileIdOfSwitchId) {
      return;
    }
    let tileId = $gameTemp.tileIdOfSwitchId[switchId];
    if (tileId) {
      const newValue = $gameSwitches.value(switchId);
      const indices = $gameTemp.indicesOfTileId[tileId];
      tileId = newValue ? 0 : tileId;
      for (const index of indices) {
        $dataMap.data[index] = tileId;
      }
    }
  };

  const modifyAllMapTiles = () => {
    if ($gameTemp.tileIdOfSwitchId) {
      const switches = Object.keys($gameTemp.tileIdOfSwitchId);
      for (const switchId of switches) {
        modifyMapTile(+switchId);
      }
    }
  };

  //
  // overwrite map data (reset, resume)
  //
  const _Game_Map_setup = Game_Map.prototype.setup;
  Game_Map.prototype.setup = function(mapId) {
    $gameTemp.resetTileHash();
    _Game_Map_setup.call(this, mapId);
  };

  const _Scene_Map_onMapLoaded = Scene_Map.prototype.onMapLoaded;
  Scene_Map.prototype.onMapLoaded = function() {
    _Scene_Map_onMapLoaded.call(this);
    $gameMap._processSettingEvent();
    modifyAllMapTiles();
  };
})();
