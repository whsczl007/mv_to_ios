//=============================================================================
// Plugin for RPG Maker MZ
// KnightMoveEvent.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Enables to make event move like Knight in Chess
 * @author Sasuke KANNAZUKI
 *
 * @param Knight Movable Region Id
 * @desc Knight cannot move except this region.
 * @type number
 * @max 255
 * @min 1
 * @default 1
 *
 * @param switchOnCancel
 * @text Switch ID on Cancel
 * @desc Switch ID become ON when player give up to solve.
 * @type switch
 * @min 1
 * @default 50
 *
 * @command start
 * @text Start Knight Move
 * @desc During knight is moving, player cannot move.
 *
 * @command complete
 * @text At Problem is Solved
 * @desc Call when the problem is solved.
 *
 * @help
 * This plugin runs under RPG Maker MZ.
 * 
 * This plugin enables the event that moves knight in chess.
 * This plugin assumes the use of knight move puzzle,
 * So, during knight moving, player cannot move.
 *
 * [Summary]
 * Describe <KnightMove> to the event's note and the event
 * become knight move event.
 * Knight move event only can move to specified region.
 *
 * Knight move event must be singleton in the each map.
 *
 * Execute plugin command to become knight move mode.
 * At knight move mode, it displays destinations.
 * 
 * Player can select destination by direction keys,
 * and the kinght performs jump when input OK key(enter and so on).
 *
 * Player also be able to tap(or click) one of destinations to
 * knight jump to the position.
 *
 * Trigger cancel key to finish kinght move mode and player character
 * can move again.
 *
 *
 * [License]
 * this plugin is released under MIT license.
 * http://opensource.org/licenses/mit-license.php
 */

/*:ja
 * @target MZ
 * @plugindesc 桂馬飛びをするイベントを作成します
 * @author 神無月サスケ
 *
 * @param Knight Movable Region Id
 * @text 桂馬移動可能リージョンID
 * @desc 桂馬イベントはこのリージョン以外に着地できません。
 * @type number
 * @max 255
 * @min 1
 * @default 1
 *
 * @param switchOnCancel
 * @text キャンセル時起動スイッチ
 * @desc キャンセルされた際にONになるスイッチIDです。
 * @type switch
 * @min 1
 * @default 50
 *
 * @command start
 * @text 桂馬イベント移動開始
 * @desc 桂馬イベントの動作モードに移ります。
 * 動作中はプレイヤーは移動しません。
 *
 * @command complete
 * @text 桂馬イベントクリア
 * @desc イベントをクリアした時に呼び出してください。
 * このプラグインではクリア判定を行いません。
 *
 * @help
 * このプラグインは、RPGツクールMZに対応しています。
 *
 * このプラグインは、桂馬飛びをするイベントを作成します。
 * 桂馬飛びパズルでの使用を想定しており、
 * 桂馬飛びイベント起動中はプレイヤーは移動できません。
 *
 * ■概要
 * イベントのメモに<KnightMove>と書かれていれば、
 * そのイベントが桂馬(チェスのナイト)になります。
 * 桂馬イベントは、指定されたリージョン内しか移動できません。
 *
 * 桂馬イベントは、マップにひとつしか置くことが出来ません。
 *
 * プラグインコマンドで桂馬イベントモードに切り替わると、
 * 桂馬の移動先が色付きで表示されるようになります。
 * 
 * 上下左右のキーで移動先を変更することが可能で、
 * 決定キーが押された場合、選択中の座標にジャンプします。
 *
 * または、任意の移動先をタップやクリックすることでも
 * 移動させることが可能です。
 *
 * キャンセルキーを押すと、桂馬モードを終了し、プレイヤーの移動に戻ります。
 *
 * ■ライセンス表記
 * このプラグインは MIT ライセンスで配布されます。
 * ご自由にお使いください。
 * http://opensource.org/licenses/mit-license.php
 */

(() => {
  const pluginName = 'KnightMoveEvent';
  //
  // process parameters
  //
  const parameters = PluginManager.parameters(pluginName);
  const knightRegion = Number(parameters['Knight Movable Region Id'] || 1);
  const switchOnCancel = Number(parameters['switchOnCancel'] || 50);

  //
  // process plugin commands
  //
  PluginManager.registerCommand(pluginName, 'start', args => {
    if ($gameMap.knight()) {
      $gameMap.knight().isKnightMoving = true;
    }
  });

  PluginManager.registerCommand(pluginName, 'complete', args => {
    if ($gameMap.knight()) {
      $gameMap.knight().isKnightMoving = false;
    }
  });

  //
  // initialize map: check map whether knight is in the map or not.
  //
  const _Game_Map_setupEvents = Game_Map.prototype.setupEvents;
  Game_Map.prototype.setupEvents = function() {
    this.knightId = 0;
    const isKnight = event => event.meta.KnightMove;
    const isThereK = $dataMap.events.filter(e => !!e).some(e => isKnight(e));
    if (isThereK) { // Map with Knight
      this._events = [];
      this._commonEvents = [];
      for (const event of $dataMap.events.filter(event => !!event)) {
        if (isKnight(event)) {
          this._events[event.id] = new Game_KnightMove(this._mapId, event.id);
          this.knightId = event.id;
        } else {
          this._events[event.id] = new Game_Event(this._mapId, event.id);
        }
      }
      for (const commonEvent of this.parallelCommonEvents()) {
        this._commonEvents.push(new Game_CommonEvent(commonEvent.id));
      }
      this.refreshTileEvents();
    } else { // normal map
      _Game_Map_setupEvents.call(this);
    }
  };

  //
  // judge function whether the event is knight or not
  //
  Game_Event.prototype.isKnight = function () {
    return this.eventId === $gameMap.knightId;
  };

  Game_Map.prototype.knight = function () {
    return this.knightId ? this.event(this.knightId) : null;
  };

  Game_Map.prototype.isKnightMoving = function () {
    return this.knightId ? this.knight().isKnightMoving : false;
  };

  //
  // during knight move mode, player cannot move, knight moves instead.
  //

  const _Game_Player_canMove = Game_Player.prototype.canMove;
  Game_Player.prototype.canMove = function() {
    return _Game_Player_canMove.call(this) && !$gameMap.isKnightMoving();
  };

  const _Scene_Map_isMenuEnabled = Scene_Map.prototype.isMenuEnabled;
  Scene_Map.prototype.isMenuEnabled = function() {
    return _Scene_Map_isMenuEnabled.call(this) && !$gameMap.isKnightMoving();
  };

  //
  // utility functions
  //
  const isRegionOk = (x, y) => {
    const rx = $gameMap.roundX(x);
    const ry = $gameMap.roundY(y);
    return knightRegion === $gameMap.regionId(rx, ry);
  };

  //---------------------------------------------------------------------------
  // Game_KnightMove
  //
  // this is an special event that moves like knight in chess.
  // 
  function Game_KnightMove() {
    this.initialize(...arguments);
  }

  Game_KnightMove.prototype = Object.create(Game_Event.prototype);
  Game_KnightMove.prototype.constructor = Game_KnightMove;

  Game_KnightMove.prototype.initialize = function(mapId, eventId) {
    this.setupDestinations();
    this.setupMembers();
     Game_Event.prototype.initialize.call(this, mapId, eventId);
  };

  //
  // setup destinations and initial position
  //
  Game_KnightMove.prototype.setupDestinations = function () {
    this.destinations = new Array(8);
    let dx, dy, id;
    for (let i = 0; i < 2; i++) {
      for (let j = 0; j < 2; j++) {
        for (let k = 0; k < 2; k++) {
          dx = dy = 1;
          k === 0 ? dx++ : dy++;
          dx = j === 0 ? -dx : dx;
          dy = i === 0 ? -dy : dy;
          id = i * 4 + j * 2 + k;
          this.destinations[id] = new Game_KnightDestination(dx, dy, this);
        }
      }
    }
  };

  const dxdyToId = (dx, dy) => {
    let id = 0;
    id += Math.abs(dy) === 2 ? 1 : 0;
    id += dx > 0 ? 2 : 0;
    id += dy > 0 ? 4 : 0;
    return id;
  };

  Game_KnightMove.prototype.setupMembers = function () {
    this.dx = 1;
    this.dy = -2;
    this.isKnightMoving = false;
    this._isKnightJumping = false;
    this.visibleChildren = true;
    this.willStopMoving = false;
  };

  //
  // update and refresh function
  //
  Game_KnightMove.prototype.update = function () {
    Game_Event.prototype.update.call(this);
    for (const destination of this.destinations) {
      destination.update();
    }
    if (!this.isKnightMoving) {
      return;
    }
    if (!this.updateJump2() && this._waitCount > 0) {
      this._waitCount--;
    } else if (this.cursorMoveByInput()){
      this.refresh();
    } else if (this.willStopMoving) {
      this.isKnightMoving = false;
      this.willStopMoving = false;
      $gameSwitches.setValue(switchOnCancel, true);
    }
    this.updateCancel();
  };

  Game_KnightMove.prototype.refresh = function () {
    for (const destination of this.destinations) {
      destination.refresh();
    }
    Game_Event.prototype.refresh.call(this);
  };

  Game_KnightMove.prototype.updateCancel = function () {
    if (Input.isTriggered("cancel") || TouchInput.isCancelled()) {
      this.willStopMoving = true;
    }
  };

  //
  // when 'ok' handler invoked, perform jump
  //
  Game_KnightMove.prototype.updateJump2 = function () {
    if (this._isKnightJumping && !this.isJumping()) {
      this.onFinishJump();
      return true;
    } else if (!this._isKnightJumping) {
      if (Input.isTriggered("ok")) {
        if (isRegionOk(this.x + this.dx, this.y + this.dy)) {
          this.onStartJump(this.dx, this.dy);
          return true;
        }
        return false;
      } else if (TouchInput.isTriggered()) {
        const x = $gameMap.canvasToMapX(TouchInput.x);
        const y = $gameMap.canvasToMapY(TouchInput.y);
        const dx = $gameMap.deltaX(x, this.x);
        const dy = $gameMap.deltaY(y, this.y);
        if (isRegionOk(x, y) && dx ** 2 + dy ** 2 === 5) {
          this.dx = dx;
          this.dy = dy;
          this.onStartJump(this.dx, this.dy);
          return false;
        }
      } else {
        return false;
      }
    }
  };

  Game_KnightMove.prototype.onStartJump = function (dx, dy) {
    this._isKnightJumping = true;
    this.visibleChildren = false;
    this.jump(dx, dy);
    this._waitCount = 0;
    this.refresh();
  };

  Game_KnightMove.prototype.onFinishJump = function () {
    this._isKnightJumping = false;
    this.visibleChildren = true;
    for (const event of $gameMap.eventsXy(this.x, this.y)) {
      event.start();
    }
  };

  //
  // when 4-dir input, change next destination (dx, dy).
  //
  Game_KnightMove.prototype.moveRight = function () {
    if (this.dx < 1) {
      const ox = this.dx;
      this.dx += this.dx === -1 ? 2 : 1;
      this.dy += ox === -1 ? 0 : ox === 1 ^ this.dy === 1 ? 1 : -1;
      return true;
    }
    return false;
  };

  Game_KnightMove.prototype.moveLeft = function () {
    if (this.dx > -1) {
      const ox = this.dx;
      this.dx += this.dx === 1 ? -2 : -1;
      this.dy += ox === 1 ? 0 : ox === -1 ^ this.dy === 1 ? 1 : -1;
      return true;
    }
    return false;
  };

  Game_KnightMove.prototype.moveDown = function () {
    if (this.dy < 1) {
      const oy = this.dy;
      this.dy += this.dy === -1 ? 2 : 1;
      this.dx += oy === -1 ? 0 : oy === 1 ^ this.dx === 1 ? 1 : -1;
      return true;
    }
    return false;
  };

  Game_KnightMove.prototype.moveUp = function () {
    if (this.dy > -1) {
      const oy = this.dy;
      this.dy += this.dy === 1 ? -2 : -1;
      this.dx += oy === 1 ? 0 : oy === -1 ^ this.dx === 1 ? 1 : -1;
      return true;
    }
    return false;
  };

  //
  // cursor move by direction input
  //
  Game_KnightMove.prototype.cursorMoveByInput = function () {
    if(!this.isMoving()) {
      const direction = this.getInputDirection();
      if (direction > 0) {
        this.executeCursorMove(direction);
      }
    }
  };

  Game_KnightMove.prototype.getInputDirection = function() {
    return Input.dir4;
  };

  Game_KnightMove.prototype.executeCursorMove = function (direction) {
    let moveSucceed = false;
    switch (direction) {
    case 2:
      moveSucceed = this.moveDown();
      break;
    case 4:
      moveSucceed = this.moveLeft();
      break;
    case 6:
      moveSucceed = this.moveRight();
      break;
    case 8:
      moveSucceed = this.moveUp();
      break;
    }
    if (moveSucceed) {
      this._waitCount = 15;
    }
    return moveSucceed;
  };

  //---------------------------------------------------------------------------
  // Game_KnightDestination
  //
  // indicates the kinght's destination.
  // 
  function Game_KnightDestination() {
    this.initialize(...arguments);
  }

  Game_KnightDestination.prototype = Object.create(Game_Character.prototype);
  Game_KnightDestination.prototype.constructor = Game_KnightDestination;

  Game_KnightDestination.prototype.initialize = function (dx, dy, parent) {
    Game_Character.prototype.initialize.call(this);
    this.dx = dx;
    this.dy = dy;
    this.parent = parent;
  };

  Game_KnightDestination.prototype.update = function () {
    this.isVisible = this.parent.isKnightMoving && this.parent.visibleChildren;
  };

  Game_KnightDestination.prototype.refresh = function () {
    this.locate(this.newX(), this.newY());
  };

  Game_KnightDestination.prototype.isSelectedByCursor = function () {
    return this.parent.dx === this.dx && this.parent.dy === this.dy;
  };

  Game_KnightDestination.prototype.isValid = function () {
    return isRegionOk(this.parent.x + this.dx, this.parent.y + this.dy);
  };

  Game_KnightDestination.prototype.newX = function () {
    return $gameMap.roundX(this.parent.x + this.dx);
  };

  Game_KnightDestination.prototype.newY = function () {
    return $gameMap.roundY(this.parent.y + this.dy);
  };

  Game_KnightDestination.prototype.screenX = function () {
    this._realX = this.newX();
    return Game_Character.prototype.screenX.call(this);
  };

  Game_KnightDestination.prototype.screenY = function () {
    this._realY = this.newY();
    return Game_Character.prototype.screenY.call(this);
  };

  //---------------------------------------------------------------------------
  // Sprite_KnightDestination
  //
  // indicates the kinght's destination.

  const knightDestColors = [
    'rgba(255, 128, 192, 0.8)', // selected
    'rgba(255, 255,  32, 0.6)', // unselected
    'rgba(192,   0,   0, 0.5)', // selected but out of region
    'rgba(128, 128, 128, 0.5)'  // out of region
  ];
  function Sprite_KnightDestination() {
    this.initialize(...arguments);
  }

  Sprite_KnightDestination.prototype =
    Object.create(Sprite.prototype);
  Sprite_KnightDestination.prototype.constructor = Sprite_KnightDestination;

  Sprite_KnightDestination.prototype.initialize = function(destination) {
    Sprite.prototype.initialize.call(this);
    this._destination = destination;
    this._currentColorId = -1;
  };

  Sprite_KnightDestination.prototype.update = function () {
    Sprite.prototype.update.call(this);
    this.visible = this._destination.isVisible;
    if (this.visible) {
      this.updatePosition();
      this.updateBitmap();
    }
  };

  Sprite_KnightDestination.prototype.currentColorId = function () {
    const selected = this._destination.isSelectedByCursor();
    const isInRegion = this._destination.isValid();
    return (selected ? 0 : 1) + (isInRegion ? 0 : 2);
  };

  Sprite_KnightDestination.prototype.updateBitmap = function() {
    if (this._currentColorId === -1) {
      const tileWidth = $gameMap.tileWidth();
      const tileHeight = $gameMap.tileHeight();
      this.bitmap = new Bitmap(tileWidth, tileHeight);
      this.anchor.x = 0.5;
      this.anchor.y = 1;
    }
    const colorId = this.currentColorId();
    if (colorId !== this._currentColorId) {
      this._currentColorId = colorId;
      const color = knightDestColors[colorId];
      this.bitmap.clear();
      this.bitmap.fillAll(color);
    }
  };

  Sprite_KnightDestination.prototype.updatePosition = function() {
    this.x = this._destination.screenX();
    this.y = this._destination.screenY() + 6;
    this.z = 1;
  };

  //
  // register sprite knight destination
  //
  const _Spriteset_Map_createCharacters =
    Spriteset_Map.prototype.createCharacters;
  Spriteset_Map.prototype.createCharacters = function() {
    let _characterSprites = [];
    if ($gameMap.knight()) {
      for (const dest of $gameMap.knight().destinations) {
        _characterSprites.push(new Sprite_KnightDestination(dest));
      }
    }
    for (const sprite of _characterSprites) {
      this.addChild(sprite);
    }
    _Spriteset_Map_createCharacters.call(this);
  };
})();
