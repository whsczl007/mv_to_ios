//=============================================================================
// Plugin for RPG Maker MZ
// BrittleFloor.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Make the brittle floor that crumbles if player steps there twice
 * @author Sasuke KANNAZUKI
 *
 * @param Crack SE File Name
 * @desc The SE that plays when the floor tile cracks.
 * Brittle floor cracks when player step there at first.
 * @default Ice2
 * @require 1
 * @dir audio/se/
 * @type file
 *
 * @param Crack SE volume
 * @parent Crack SE File Name
 * @desc The volume of SE that plays when the floor tile cracks.
 * @type number
 * @min 0
 * @default 90
 * 
 * @param Crack SE pitch
 * @parent Crack SE File Name
 * @desc The pitch of SE that plays when the floor tile cracks.
 * @type number
 * @max 100000
 * @min 10
 * @default 100
 * 
 * @param Crumble SE File Name
 * @desc The SE that plays when the floor tile crumbles.
 * When brittle floor crumbles, player falls in the hole.
 * @default Fall
 * @require 1
 * @dir audio/se/
 * @type file
 *
 * @param Crumble SE volume
 * @parent Crumble SE File Name
 * @desc The volume of SE that plays when the floor tile crumbles.
 * @type number
 * @min 0
 * @default 90
 * 
 * @param Crumble SE pitch
 * @parent Crumble SE File Name
 * @desc The pitch of SE that plays when the floor tile crumbles.
 * @type number
 * @max 100000
 * @min 10
 * @default 100
 * 
 * @command set
 * @text Set Brittle Region ID
 * @desc The tile is brittle when its region ID is this.
 *
 * @arg regionId
 * @text Region ID
 * @desc If Region ID is already set, it overwrites.
 * @type number
 * @min 1
 * @default 1
 *
 * @arg eventID
 * @text Templete Map Event ID
 * @desc The event in the map whose images of page1 is crack, page2 is pitfall.
 * @type number
 * @min 1
 * @default 1
 *
 * @arg destMapId
 * @text Fall Destination Map ID
 * @desc Destination Map when player falls from crumbled floor.
 * The destination's coord is the same as the floor tile.
 * @type number
 * @min 1
 * @default 1
 *
 * @command reset
 * @text Reset Brittle Region ID
 * @desc Explicitly Reset brittle attribute of all tiles.
 * Note: Without calling this, region is reset when map changes.
 *
 * @help
 * This plugin runs under RPG Maker MZ.
 * 
 * This plugin enables to make brittle floor like thin ice floor,
 * the floor made of sand, and so on.
 *
 * Player step brittle floor, the tile cracks, and step it again,
 * the floor crumbles and player fall beneath floor.
 *
 * Cracs and crumbles are reset when player go to another map.
 * You can also fix by plugin command.
 *
 * This plugin assumes to make the dungeon gimic.
 *
 * [Summary]
 * To set the specified region brittle, you must call plugin command.
 *
 * To set the tile id of cracs and crumble hole, you must set dummy
 * event in the map. Set crack tile at the page 1's image,
 * set the crumble tile at the page 2's image.
 * Since the event is dummy(only for set image), the event must be invisible.
 * I recommend make page 3 without image and set no conditions.
 * Note that those images must be the tile. If invalid image is set,
 * brittle tile is not set.
 *
 * Note that the tile for cracs must be passable. Otherwise, player cannot
 * move when crac is made under the player.
 *
 * And you must make beneath floor's map with brittle tiles.
 * When player step brittle tile twice and fall, Player move to the map
 * as the beneath floor.
 * When player falls, player is located the same coord to the map,
 * so the beneath map width and height must be the same or larger.
 *
 * Note that brittle setting is reset when player move to the another map.
 * So, I recommend to run the pluguin command each time when player enter
 * the map.
 *
 * [License]
 * this plugin is released under MIT license.
 * http://opensource.org/licenses/mit-license.php
 */

/*:ja
 * @target MZ
 * @plugindesc 二度乗ると崩れる脆い床を作成します
 * @author 神無月サスケ
 *
 * @param Crack SE File Name
 * @text クラック時のSE
 * @desc 床にひびが入る時に演奏されるSEのファイル名です。
 * @default Ice2
 * @require 1
 * @dir audio/se/
 * @type file
 *
 * @param Crack SE volume
 * @text クラック時SEボリューム
 * @parent Crack SE File Name
 * @desc 床にひびが入る時に演奏されるSEのボリューム
 * @type number
 * @min 0
 * @default 90
 * 
 * @param Crack SE pitch
 * @text クラック時SEピッチ
 * @parent Crack SE File Name
 * @desc 床にひびが入る時に演奏されるSEのピッチ
 * @type number
 * @max 100000
 * @min 10
 * @default 100
 * 
 * @param Crumble SE File Name
 * @text 床崩壊時のSE
 * @desc 床崩壊時に演奏されるSEのファイル名です。
 * 床崩壊とともにプレイヤーは落とされます。
 * @default Fall
 * @require 1
 * @dir audio/se/
 * @type file
 *
 * @param Crumble SE volume
 * @text 床崩壊時SEボリューム
 * @parent Crumble SE File Name
 * @desc 床崩壊時に演奏されるSEのボリューム
 * @type number
 * @min 0
 * @default 90
 * 
 * @param Crumble SE pitch
 * @text 床崩壊時SEピッチ
 * @parent Crumble SE File Name
 * @desc 床崩壊時に演奏されるSEのピッチ
 * @type number
 * @max 100000
 * @min 10
 * @default 100
 * 
 * @command set
 * @text 脆い床リージョン設定
 * @desc このリージョンの位置が脆い床になります。
 *
 * @arg regionId
 * @text リージョンID
 * @desc 
 * @type number
 * @min 1
 * @default 1
 *
 * @arg eventID
 * @text 雛形マップイベントID
 * @desc ひびや落とし穴の画像を設定するイベントです。
 * 1ページ目の画像がひび、2ページ目が落とし穴です。
 * @type number
 * @min 1
 * @default 1
 *
 * @arg destMapId
 * @text 落下先マップID
 * @desc 崩れる床から落ちた先のマップID。
 * 座標は元のマップと同じ位置になります。
 * @type number
 * @min 1
 * @default 1
 *
 * @command reset
 * @text 脆い床リージョン解除
 * @desc タイルの脆い属性を明示的にリセットします。
 * 注意：リージョンは、マップが変われば自動的にリセットされます。
 *
 * @help
 * このプラグインは、RPGツクールMZに対応しています。
 *
 * このプラグインは、砂や薄氷のように、一度乗るとひびが入り、
 * またそこに乗ると下のフロアに落とされる、といった「脆い床」を
 * 作成することが出来ます。
 *
 * 一度床にひびが入っても、マップを切り替えれば元の状態に戻る他、
 * イベントコマンドでリセットする（床のひびも消える）ことも可能です。
 *
 * 主にダンジョンギミックでの使用を想定して作られました。
 *
 * ■概要
 * プラグインコマンドによって、特定のリージョンを「脆い床」として
 * 定義します。
 *
 * 脆い床に描かれるひびや落とし穴のタイルは、
 * イベントで指定します。ダミーのイベントを準備し、
 * １ページ目にひび、２ページ目に落とし穴のタイルを
 * 画像としてセットします。
 * このダミーの画像用イベントは壁の中に置いたり、３ページ目を無条件にして
 * 常に表示させないことが必要です。
 * イベントの画像がタイル以外など無効な場合は、脆い床は設定されません。
 *
 * ひびや落とし穴として指定するタイルは、通行可能に設定してください。
 * さもなくば、ひびが出来た時、プレイヤーが移動できなくなってしまいます。
 *
 * また、プラグインコマンドでは、穴に落ちた際に移動するマップも指定必須です。
 * 落ちた先のマップでは、落ちる前と同じ座標になるため、必ず、落ちる先のマップは
 * 脆い床のあるマップと同等かそれ以上の広さにしてください。
 *
 * 一度脆い床を設定しても、別のマップから戻ってきたときは設定は
 * リセットされているため、マップ開始時に自動実行での
 * プラグインコマンド呼び出しを推奨します。
 *
 * ■ライセンス表記
 * このプラグインは MIT ライセンスで配布されます。
 * ご自由にお使いください。
 * http://opensource.org/licenses/mit-license.php
 */

(() => {
  const pluginName = 'BrittleFloor';
  //
  // process parameters
  //
  const parameters = PluginManager.parameters(pluginName);
  const seCrackFilename = parameters['Crack SE File Name'] || '';
  const seCrackVolume = Number(parameters['Crack SE volume'] || 90);
  const seCrackPitch = Number(parameters['Crack SE pitch'] || 100);
  const seFallFilename = parameters['Crumble SE File Name'] || '';
  const seFallVolume = Number(parameters['Crumble SE volume'] || 90);
  const seFallPitch = Number(parameters['Crumble SE SE pitch'] || 100);

  //
  // utility functions
  //
  const playCrack = () => {
    const audio = {name:seCrackFilename, volume:seCrackVolume,
      pitch:seCrackPitch
    };
    AudioManager.playStaticSe(audio);
  };

  const playFall = () => {
    const audio = {name:seFallFilename, volume:seFallVolume,
      pitch:seFallPitch
    };
    AudioManager.playSe(audio);
  };

  const setDataMap = (x, y, z, tileId) => {
    // see Game_Map.prototype.tileId
    const width = $dataMap.width;
    const height = $dataMap.height;
    $dataMap.data[(z * height + y) * width + x] = tileId;
  };

  const aToNum = (x, y) => (y << 12) + x;
  const numToX = num => num & 0xfff;
  const numToY = num => num >> 12;

  //
  // process plugin commands
  //
  PluginManager.registerCommand(pluginName, 'set', args => {
    const event = $dataMap.events[+args.eventID];
    if (event) {
      const image0 = event.pages[0].image.tileId;
      const image1 = event.pages[1] ? event.pages[1].image.tileId : 0;
      if (image0 && image1) {
        $gameMap._resetCracks();
        $gameMap._setBrittleFloors(args, image0, image1);
      }
    }
  });

  PluginManager.registerCommand(pluginName, 'reset', args => {
    $gameMap._resetCracks();
    $gameMap._initBrittleFloors();
  });

  //
  // initialize/resume britter floors
  //
  Game_Map.prototype._initBrittleFloors = function () {
    this._brittleRegionId = 0;
    this._brittleMapId = 0;
    this._brittleFloors = null;
    this._crackTileId = 0;
    this._crumbleTileId = 0;
    this._fallDestMapId = 0;
  };

  Game_Map.prototype._setBrittleFloors = function (args, image0, image1) {
    this._brittleRegionId = +args.regionId;
    this._brittleMapId = this.mapId();
    this._brittleFloors = null;
    this._crackTileId = image0;
    this._crumbleTileId = image1;
    this._fallDestMapId = +args.destMapId;
  };

  Game_Map.prototype._isThereBrittleFloor = function () {
    return !!this._brittleRegionId;
  };

  const _Game_Map_setup = Game_Map.prototype.setup;
  Game_Map.prototype.setup = function(mapId) {
    _Game_Map_setup.call(this, mapId);
    this._setBrittleFloor();
  };

  Game_Map.prototype._needsSetBrittleFloor = function () {
    if (this._isThereBrittleFloor()) {
      if (this.mapId() === this._brittleMapId) {
        return true;
      }
    }
    return false;
  };

  Game_Map.prototype._setBrittleFloor = function () {
    if (this._needsSetBrittleFloor()) {
      this._setCracks();
    } else {
      this._initBrittleFloors();
    }
  };

  Game_Map.prototype._setCracks = function () {
    if (!this._brittleFloors) {
      return;
    }
    const z = 1; // layer 2
    const coords = Object.keys(this._brittleFloors);
    for (const coord of coords) {
      const x = numToX(coord);
      const y = numToY(coord);
      if (this._brittleFloors[aToNum(x, y)]) {
        setDataMap(x, y, z, this._crackTileId);
      }
    }
  };

  Game_Map.prototype._resetCracks = function () {
    this._crackTileId = 0;
    this._setCracks();
  };

  //
  // when load data, call process drawing routine
  //
  const _Scene_Map_onMapLoaded = Scene_Map.prototype.onMapLoaded;
  Scene_Map.prototype.onMapLoaded = function() {
    _Scene_Map_onMapLoaded.call(this);
    $gameMap._setBrittleFloor();
  };

  // NOTE: this function prevents crack resets when load after project update.
  // When you change the map with brittle floor, map is not modified,
  // To refrect modification, you need to once go to another map
  // and return to the map.
  const _Scene_Load_reloadMapIfUpdated =
    Scene_Load.prototype.reloadMapIfUpdated;
  Scene_Load.prototype.reloadMapIfUpdated = function() {
    if ($gameMap._needsSetBrittleFloor()) {
      return; 
   }
    _Scene_Load_reloadMapIfUpdated.call(this);
  };

  //
  // process step on brittle tile
  //
  const _Game_Party_onPlayerWalk = Game_Party.prototype.onPlayerWalk;
  Game_Party.prototype.onPlayerWalk = function() {
    _Game_Party_onPlayerWalk.call(this);
    $gameMap._onPlayerWalkBrittle();
  };

  Game_Map.prototype._onPlayerWalkBrittle = function () {
    if (this._isThereBrittleFloor()) {
      if (this._brittleRegionId === $gamePlayer.regionId()) {
        if (!this._brittleFloors) {
          this._brittleFloors = {};
        }
        const x = $gamePlayer.x;
        const y = $gamePlayer.y;
        const d = $gamePlayer.direction();
        if (this._brittleFloors[aToNum(x, y)]) {
          setDataMap(x, y, 1, this._crumbleTileId);
          const destMapId = this._fallDestMapId;
          $gamePlayer.reserveTransfer(destMapId, x, y, d, 0);
          playFall();
        } else {
          setDataMap(x, y, 1, this._crackTileId);
          this._brittleFloors[aToNum(x, y)] = true;
          playCrack();
        }
      }
    }
  };

})();
