//=============================================================================
// Plugin for RPG Maker MZ
// LuiseLib.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Utility functions for Luise the RMMV sample
 * @author Sasuke KANNAZUKI
 *
 * @requiredAssets audio/bgm/luise_m_battle01
 * @requiredAssets audio/bgm/luise_m_battle03
 * @requiredAssets audio/bgm/luise_m_battle07
 * @requiredAssets audio/bgm/luise_m_scene09
 *
 * @orderAfter SmartAutoBattle
 * @orderAfter SymbolEncountLibMZ
 *
 * @help
 * This plugin runs under RPG Maker MZ.
 * This plugin defines miscellaneous functions for the game.
 *
 * [License]
 * this plugin is released under MIT license.
 * http://opensource.org/licenses/mit-license.php
 */

/*:ja
 * @target MZ
 * @plugindesc 「ルイーゼと秘密の地下室」の専用機能ライブラリ
 * @author 神無月サスケ
 *
 * @requiredAssets audio/bgm/luise_m_battle01
 * @requiredAssets audio/bgm/luise_m_battle03
 * @requiredAssets audio/bgm/luise_m_battle07
 * @requiredAssets audio/bgm/luise_m_scene09
 *
 * @orderAfter SmartAutoBattle
 * @orderAfter SymbolEncountLibMZ
 *
 * @help
 * このプラグインは、RPGツクールMZに対応しています。
 * このプラグインは、MZサンプルゲーム「ルイーゼと秘密の地下室」でのみ
 * 有効です。
 *
 * ■ライセンス表記
 * このプラグインは MIT ライセンスで配布されます。
 * ご自由にお使いください。
 * http://opensource.org/licenses/mit-license.php
 */

(() => {
  const pluginName = 'LuiseLib';

  //
  // Set Carla's character opacity until she realized.
  //

  // actor is Carla and she is not complete realization yet
  const isHalfOpacity = actor => {
    return actor && actor.actorId() === 2 &&
      (!$gameSwitches.value(84) && !$gameSwitches.value(81)
    );
  };

  Game_CharacterBase.prototype.isHalfOpacity = function() {
    return false;
  };

  Game_Player.prototype.isHalfOpacity = function() {
    return isHalfOpacity($gameParty.leader());
  };

  Game_Follower.prototype.isHalfOpacity = function() {
    return isHalfOpacity(this.actor());
  };

  const _Sprite_Character_updateOther =
    Sprite_Character.prototype.updateOther;
  Sprite_Character.prototype.updateOther = function() {
    _Sprite_Character_updateOther.call(this);
    if (this._character.isHalfOpacity()) {
      this.opacity = Math.floor(this.opacity / 2);
    }
  };

  //
  // Set normal battle bgm according to the top actor of party
  //
  const doesBelongToLuiseGroup = actorId => [1,2,3].includes(actorId);
  const doesBelongToRyleGroup = actorId => [4,5].includes(actorId);
  const isLeaderCremina = actorId => actorId === 7;

  const buildBgm = name => {
    return {'name':name, pan:0, pitch:100, volume:90};
  };

  const _Game_System_battleBgm = Game_System.prototype.battleBgm;
  Game_System.prototype.battleBgm = function() {
    const originalBgm = _Game_System_battleBgm.call(this);
    if ((/^luise_m_battle0[13]$/i).test(originalBgm.name)) {
      const leader = $gameParty.leader();
      const leaderId = leader ? leader.actorId() : 0;
      if (doesBelongToLuiseGroup(leaderId)) {
        return buildBgm('luise_m_battle01');
      } else if (doesBelongToRyleGroup(leaderId)) {
        return buildBgm('luise_m_battle03');
      } else if (isLeaderCremina(leaderId)) {
        return buildBgm('luise_m_battle07');
      }
    }
    return originalBgm;
  };

  //
  // Change Encounter and party condition at Anton's Dungeon
  //
  Game_Player.prototype.executeEncounter = function() {
    // no random encounter
    return false;
  };

  // called at Anton's dungeon
  Game_Temp.prototype.antonAdded = function() {
    $dataMap.encounterList = [
      {"troopId":26,"weight":5,"regionSet":[]},
      {"troopId":27,"weight":5,"regionSet":[]},
      {"troopId":28,"weight":5,"regionSet":[]},
      {"troopId":29,"weight":5,"regionSet":[]},
      {"troopId":30,"weight":5,"regionSet":[]}
    ];

    // change troop id of each symbol.
    for (const event of $gameMap.events()) {
      if (event.isSymEnc) {
        if (+event.event().meta.troop === 0) {
          event.SymEncTroopID = $gamePlayer.makeEncounterTroopId();
        }
      }
    }
  };

  //
  // refine AI considering current troop
  //
  let ketosState = 0;

  const _Game_Action_evaluateWithTarget =
    Game_Action.prototype.evaluateWithTarget;
  Game_Action.prototype.evaluateWithTarget = function(target) {
    let value = _Game_Action_evaluateWithTarget.call(this, target);
    value = value || 0;
    // for last boss, Luise should use meteor.
    if ($gameTroop._troopId === 8) {
      if (this.isSkill() && this.item().id === 34) {
        value += 4;
      }
    }
    // for special boss, it should consider elementId
    if ($gameTroop._troopId === 9) {
      const subject = this.subject();
      ketosState = $gameTroop.members()[0]._states[0];
      if (subject.isActor() && subject.actorId() === 7) {
        const elementId = +this.item().meta.elementId;
        if (elementId) {
          if (this.isDamage()) {
            value += this.calcElementRate(target) > 0 ? 2 : -2;
          } else {
            let rate = this.calcElementRate($gameTroop.members()[0]);
            let set = target.attackElements().includes(elementId);
            if (this.isForAll()) {
              value += rate && !set ? 2 : -1;
            } else {
              value += rate ? 2 : -2;
              value += set ? -1 : 0;
            }
          }
        }
      }
    }
    return value;
  };

  const _BattleManager_startAction = BattleManager.startAction;
  BattleManager.startAction = function() {
    if ($gameTroop._troopId === 9) {
      const subject = this._subject;
      const action = subject.currentAction();
      if (action._autoSelected) {
        if (subject.isActor() && subject.actorId() === 7) {
          const currentState = $gameTroop.members()[0]._states[0];
          if (currentState !== ketosState) {
            // discard current actions and recreate new ones with considering
            // current condition.
            subject.makeAutoBattleActions();
            ketosState = currentState;
          }
        }
      }
    }
    _BattleManager_startAction.call(this);
  };

})();
