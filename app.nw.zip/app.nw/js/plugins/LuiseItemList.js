//=============================================================================
// Plugin for RPG Maker MZ
// LuiseItemList.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Make Item List for Each Party
 * @author Sasuke KANNAZUKI
 *
 * @command toggle
 * @text Change Paerty
 * @desc Call when party changes.
 * Item List is modified.
 *
 * @arg PartyID
 * @desc Party ID and Leader's Name
 * @type select
 * @option Luise
 * @value 0
 * @option Ryle
 * @value 1
 * @default 0
 *
 * @command merge
 * @text Merge Party
 * @desc Call when party marges.
 * Item List is modified.
 *
 * @help
 * This plugin runs under RPG Maker MZ.
 *
 * This plugin enables to separated item list for each party.
 * This plugin is made for ルイーゼと秘密の地下室(Luise and Secret Basements)
 * the sample game of RMMZ.
 *
 * [Summary]
 * Call plugin to toggle or merge party items.
 *
 * [License]
 * this plugin is released under MIT license.
 * http://opensource.org/licenses/mit-license.php
 */

/*:ja
 * @target MZ
 * @plugindesc 複数パーティーのそれぞれに所持アイテムを持たせます
 * @author 神無月サスケ
 *
 * @command toggle
 * @text パーティ切り替え
 * @desc 指定したパーティのアイテムに切り替わります。
 *
 * @arg PartyID
 * @text パーティーID
 * @desc パーティーIDをリーダーの名前で設定します。
 * @type select
 * @option ルイーゼ
 * @value 0
 * @option ライル
 * @value 1
 * @default 0
 *
 * @command merge
 * @text パーティー合流
 * @desc 全てのパーティーのアイテムが共用されます。
 *
 * @help
 * このプラグインは、RPGツクールMZに対応しています。
 *
 * このプラグインは、複数のパーティーを交互に動かすゲームで、
 * パーティの切り替えに合わせてアイテムリストを変更することが可能になります。
 *
 * このプラグインは、MZサンプルゲーム「ルイーゼと秘密の地下室」のために
 * 制作されました。
 *
 * ■プラグインコマンド
 * パーティーを入れ替えたり、合流させたりした時に呼び出してください。
 *
 * ■ライセンス表記
 * このプラグインは MIT ライセンスで配布されます。
 * ご自由にお使いください。
 * http://opensource.org/licenses/mit-license.php
 */

(() => {
  const pluginName = 'LuiseItemList';
  //
  // process plugin commands
  //
  PluginManager.registerCommand(pluginName, 'toggle', args => {
    $gameParty.togglePartyItems(+args.PartyID);
  });

  PluginManager.registerCommand(pluginName, 'merge', args => {
    $gameParty.mergePartyItems();
  });

  //
  // initialization
  //
  const _Game_Party_initialize = Game_Party.prototype.initialize;
  Game_Party.prototype.initialize = function() {
    _Game_Party_initialize.call(this);
    this._currentUnit = 0;
    this._otherPartyItems = null;
  };

  //
  // toggle party
  //
  Game_Party.prototype.togglePartyItems = function (index) {
    if (index !== this._currentUnit) {
      this._currentUnit = index;
      const tmpItems = this._items;
      const tmpWeapons = this._weapons;
      const tmpArmors = this._armors;
      const tmpGold = this._gold;
      if (!this._otherPartyItems) {
        this._otherPartyItems = {};
        this._otherPartyItems._items = {};
        this._otherPartyItems._weapons = {};
        this._otherPartyItems._armors = {};
        this._otherPartyItems._gold = 0;
      }
      this._items = this._otherPartyItems._items;
      this._weapons = this._otherPartyItems._weapons;
      this._armors = this._otherPartyItems._armors;
      this._gold = this._otherPartyItems._gold;
      this._otherPartyItems._items = tmpItems;
      this._otherPartyItems._weapons = tmpWeapons;
      this._otherPartyItems._armors = tmpArmors;
      this._otherPartyItems._gold = tmpGold;
    }
  };

  //
  // merge party
  //
  Game_Party.prototype.mergePartyItems = function () {
    if (this._otherPartyItems) {
      for (const item of Object.keys(this._otherPartyItems._items)) {
	    this._items[item] = this._items[item] || 0;
        this._items[item] += this._otherPartyItems._items[item];
      }
      for (const weapon of Object.keys(this._otherPartyItems._weapons)) {
	    this._weapons[weapon] = this._weapons[weapon] || 0;
        this._weapons[weapon] += this._otherPartyItems._weapons[weapon];
      }
      for (const armor of Object.keys(this._otherPartyItems._armors)) {
	    this._armors[armor] = this._armors[armor] || 0;
        this._armors[armor] += this._otherPartyItems._armors[armor];
      }
      this._gold += this._otherPartyItems._gold;
      this._otherPartyItems = null;
    }
  };

})();
