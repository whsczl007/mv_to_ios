//=============================================================================
// Plugin for RPG Maker MZ
// NumberPuzzle.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Make the puzzle that sum of the each region is the same
 * @author Sasuke KANNAZUKI
 *
 * @command set
 * @text Start Puzzle
 * @desc Start pluzzle whose goal is 2 regions contains the same value
 *
 * @arg regionId1
 * @text Region ID 1
 * @desc First region to locate number events.
 * @type number
 * @max 255
 * @min 1
 * @default 1
 *
 * @arg regionId2
 * @text Region ID 2
 * @desc Second region to locate number events.
 * @type number
 * @max 255
 * @min 1
 * @default 2
 *
 * @arg commonIdAtClear
 * @text Common Event ID At Clear
 * @desc Invoke this common event when player solves the puzzle.
 * @type common_event
 * @default 1
 *
 * @arg switchIdAtClear
 * @text Switch ID At Clear
 * @desc Turn ON when player solves the puzzle.
 * @type switch
 * @default 1
 *
 * @command reset
 * @text Reset Clear Condition
 * @desc The events' position is not changed.
 *
 * @help 
 * This plugin runs under RPG Maker MZ.
 * 
 * This plugin supports to make the dungeon gimic
 * that the sum of event value become the same between 2 regions.
 *
 * This plugin is made for「ルイーゼと秘密の地下室」(Luise and Secret
 * Basement Rooms) the RMMV Japanese sample game.
 *
 * [Summary]
 * This plugin assumes the events that draw a number.
 * Each such event must describe the event's note indicates the event's value.
 * For example <value:2> in the note, the event's value is 2.
 *
 * The goal of the mini game is all such events are moved in a region and
 * the sum of events' value on each region is the same.
 *
 * Those events moves when player push the number event.
 *
 * [Setting : Plugin Commands]
 * To play this mini game, at first you have to call plugin command.
 * The plugin command sets each region ID and common event ID that invoke
 * when player completes the mini game, and switch ID that become ON when the
 * player completes the mini game.
 *
 * This mini game must be singleton for each map.
 *
 * After completing the map's mini game and return back to the map,
 * number events are set to the initial position, but no longer complete
 * even if events move to the appropriate position.
 *
 * If you need to invoke complete event again, reset the setting
 * by a plugin command.
 *
 * [License]
 * this plugin is released under MIT license.
 * http://opensource.org/licenses/mit-license.php
 */

/*:ja
 * @target MZ
 * @plugindesc ２つのリージョンの中にある数値の合計を等しくするパズルを作成
 * @author 神無月サスケ
 *
 * @command set
 * @text パズル開始
 * @desc 2つのリージョン内の数値を同じにするパズルを開始します。
 *
 * @arg regionId1
 * @text リージョンID1
 * @desc 数値タイルを置く１つ目のリージョンです
 * @type number
 * @max 255
 * @min 1
 * @default 1
 *
 * @arg regionId2
 * @text リージョンID2
 * @desc 数値タイルを置く２つ目のリージョンです
 * @type number
 * @max 255
 * @min 1
 * @default 1
 *
 * @arg commonIdAtClear
 * @text クリア時起動コモンイベント
 * @desc クリアした時に起動されるコモンイベントのIDです。
 * @type common_event
 * @default 1
 *
 * @arg switchIdAtClear
 * @text クリア時ONにするスイッチ
 * @desc
 * @type switch
 * @default 1
 *
 * @command reset
 * @text パズルリセット
 * @desc そのマップでのパズルのクリア状態をリセットします。
 *
 * @help 
 * このプラグインは、RPGツクールMZに対応しています。
 *
 * このプラグインは、２つのリージョン内にあるイベントの数値を
 * 同じにする謎解きの作成をサポートします。
 * 
 * MZサンプルゲーム「ルイーゼと秘密の地下室」のために作成されました。
 *
 * ■概要
 * このプラグインは、数値の書いてあるイベントを動かして、
 * ふたつのリージョンのいずれかに置き、それぞれ数値の合計が
 * 同じになったらクリア、という謎解きのためのプラグインです。
 *
 * イベントを動かすのは、岩を動かすように押して前進させるやり方です。
 *
 * 数値の書いてあるイベントは、メモに <value:2> などといった要領で
 * イベントの数値をメモに記述する必要があります。
 * これらのイベントが、全ていずれかのリージョン内にあり、
 * なおかつ数値の合計が一緒になった時にクリアになります。
 *
 * ■起動方法：プラグインコマンド
 * プラグインコマンドで、それぞれのリージョンIDおよび、
 * クリア時に起動するコモンイベントおよび、クリア時にONにするスイッチを
 * 設定します。
 *
 * このギミックはひとつのマップにひとつしか設置できません。
 * クリア後、マップを移動して戻ってくると、数値のタイルは元の場所に戻りますが、  * 再び移動させても何も起きません。
 * クリアの記録をリセットするときは、該当するプラグインコマンドを
 * 実行してください。
 *
 * ■ライセンス表記
 * このプラグインは MIT ライセンスで配布されます。
 * ご自由にお使いください。
 * http://opensource.org/licenses/mit-license.php
 */

(() => {
  const pluginName = 'NumberPuzzle';

  //
  // initialize variables
  //
  _Game_Map_initialize = Game_Map.prototype.initialize;
  Game_Map.prototype.initialize = function() {
    _Game_Map_initialize.call(this);
    this.puzzleClearMapIds = {};
  };

  const _Game_Map_setup = Game_Map.prototype.setup;
  Game_Map.prototype.setup = function(mapId) {
    _Game_Map_setup.call(this, mapId);
    this.initialPuzzle();
    this.isNumberPuzzleCleared = !!this.puzzleClearMapIds[this.mapId()];
  };

  Game_Map.prototype.initialPuzzle = function () {
    this.inNumberPuzzle = false;
    this.regionId1puzzle = -1;
    this.regionId2puzzle = -1;
    this.commonIdAtClear = 0;
    this.switchIdAtClear = 0;
  };

  //
  // process plugin commands
  //
  PluginManager.registerCommand(pluginName, 'set', args => {
    $gameMap.setPuzzle(args);
  });

  PluginManager.registerCommand(pluginName, 'reset', args => {
    $gameMap.resetPuzzle(args);
  });

  Game_Map.prototype.setPuzzle = function (args) {
    if (!this.isNumberPuzzleCleared) {
      this.inNumberPuzzle = true;
      this.regionId1puzzle = +args.regionId1;
      this.regionId2puzzle = +args.regionId2;
      this.commonIdAtClear = +args.commonIdAtClear;
      this.switchIdAtClear = +args.switchIdAtClear;
    }
  };

  Game_Map.prototype.resetPuzzle = function (args) {
    const switchId = this.switchIdAtClear;
    this.initialPuzzle();
    this.puzzleClearMapIds[this.mapId()] = false;
    this.isNumberPuzzleCleared = false;
    $gameSwitches.setValue(switchId, false);
  };

  //
  // check whether complete or not
  //
  Game_Map.prototype.isPuzzleClear = function () {
    let value1 = 0;
    let value2 = 0;
    for (const event of this.events()) {
      const value = event.event().meta.value;
      if (value) {
        const region = event.regionId();
        if (region === this.regionId1puzzle) {
          value1 += +value;
        } else if (region === this.regionId2puzzle) {
          value2 += +value;
        } else {
          return false;
        }
      }
    }
    return !!value1 && value1 === value2;
  };

  Game_Map.prototype.checkPuzzleClear = function () {
    if (this.inNumberPuzzle && !this.puzzleClearMapIds[this.mapId()]) {
      if (this.isPuzzleClear()) {
        $gameTemp.reserveCommonEvent(this.commonIdAtClear);
        this.puzzleClearMapIds[this.mapId()] = true;
        $gameSwitches.setValue(this.switchIdAtClear, true);
      }
    }
  };

  const _Game_Player_update = Game_Player.prototype.update;
  Game_Player.prototype.update = function(sceneActive) {
    _Game_Player_update.call(this, sceneActive);
    if (!$gameMap.isEventRunning() && !$gamePlayer.isMoving()) {
      $gameMap.checkPuzzleClear();
    }
  };

})();
